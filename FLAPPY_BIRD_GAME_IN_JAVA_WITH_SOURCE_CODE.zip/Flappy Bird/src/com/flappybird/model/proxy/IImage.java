/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.flappybird.model.proxy;

import javax.swing.ImageIcon;

/**
 *
 * @author derickfelix
 */
public interface IImage {
    public ImageIcon loadImage();
}
